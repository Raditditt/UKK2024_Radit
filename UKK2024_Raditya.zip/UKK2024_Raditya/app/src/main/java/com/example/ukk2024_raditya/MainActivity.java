package com.example.ukk2024_raditya;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;
public class MainActivity extends AppCompatActivity {
    private int[] tombolNumeric = {R.id.tombolnol, R.id.tombolsatu,
            R.id.tomboldua, R.id.tomboltiga, R.id.tombolempat,
            R.id.tombollima, R.id.tombolenam, R.id.tomboltujuh,
            R.id.tomboldelapan, R.id.tombolsembilan};

    private int[]tombolOperator ={R.id.tombolkali, R.id.tombolbagi,
            R.id.tomboltambah,  R.id.tombolkurang};

    private TextView layartampil;

    private TextView layarhasil;

    private boolean angkaterakhir;

    private boolean kaloError;

    private boolean setelahtitik;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.layartampil = (TextView) findViewById(R.id.LayarTampil);
        this.layarhasil = (TextView)  findViewById(R.id.layarhasil);
        setNumericpadasaatdiklik();
        setOperatorpadasaatdiklik();
    }

    private void setNumericpadasaatdiklik() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Button tombol = (Button) v;
                if (kaloError) {
                    layartampil.setText(tombol.getText());
                    kaloError = false;
                } else {
                    layartampil.append(tombol.getText());
                }
                angkaterakhir = true;
            }
        };
        for (
                int id :tombolNumeric) {
            findViewById(id).setOnClickListener(listener);
        }
    }
    private void setOperatorpadasaatdiklik() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (angkaterakhir && !kaloError) {
                    Button tombol = (Button) v;
                    layartampil.append(tombol.getText());
                    angkaterakhir = false;
                    setelahtitik = false;
                }
            }
        };
        for (int id : tombolOperator) {
            findViewById(id).setOnClickListener(listener);
        }
        findViewById(R.id.tomboltitik).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (angkaterakhir && !kaloError && !setelahtitik) {
                    layartampil.setText(".");
                    angkaterakhir = false;
                    setelahtitik = false;
                }
            }
        });
        findViewById(R.id.tombolclear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layartampil.setText(" ");
                layarhasil.setText(" ");
                angkaterakhir = false;
                kaloError = false;
                setelahtitik = false;
            }
        });
        findViewById(R.id.tombolsamadengan).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {onEqual();
            }
            private void onEqual() {
                if(angkaterakhir && !kaloError) {
                    String txt = layartampil.getText().toString();
                    Expression expression = new ExpressionBuilder(txt).build();
                    try {
                        double result = expression.evaluate();
                        layarhasil.setText( Double.toString(result));
                        setelahtitik = true;
                    }catch (ArithmeticException ex) {
                        layarhasil.setText("kesalahan");
                        kaloError = true;
                        angkaterakhir =false;
                    }
                }
            }
        });
    }
}